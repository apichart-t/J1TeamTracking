import React, { useState } from 'react';
import { FileText, RefreshCw, ClipboardCheck } from 'lucide-react';

interface InputFormProps {
  onAnalyze: (data: string) => void;
  isAnalyzing: boolean;
}

const SAMPLE_DATA = `รายงานสรุปผลการปฏิบัติงานประจำสัปดาห์ (Weekly Audit Log)

1. วันจันทร์: ฝ่ายพัฒนาระบบ (Development) ดำเนินการส่งมอบรหัสคำสั่ง (Source Code) ขึ้นสู่ระบบ Staging Server เวลา 10:00 น. ผลการดำเนินการเสร็จสมบูรณ์
2. วันอังคาร: ฝ่ายประกันคุณภาพ (QA) เริ่มการทดสอบระบบ Login ผลการทดสอบผ่านเกณฑ์ แต่ไม่พบบันทึกผลการทดสอบในระบบ Jira (ขาดเอกสารอ้างอิง)
3. วันพุธ: ไม่พบข้อมูลการปฏิบัติงานในระบบ (Gap in Timeline)
4. วันพฤหัสบดี: ผู้จัดการโครงการ (Project Manager) อนุมัติการติดตั้งระบบขึ้น Production โดยขาดผลการอนุมัติ (Sign-off) จากฝ่าย QA (ข้ามขั้นตอนการตรวจสอบ)
5. วันศุกร์: ได้รับแจ้งเหตุขัดข้องจากลูกค้าช่วงบ่าย ตรวจสอบพบสาเหตุจากการกำหนดค่า (Configuration) ไม่ถูกต้องจนส่งผลให้ Server หยุดทำงาน
6. ฝ่ายการเงิน: ตรวจสอบพบรายการเบิกจ่ายค่ารับรอง จำนวน 5,000 บาท โดยใบเสร็จรับเงินระบุวันที่เป็นวันเสาร์ซึ่งเป็นวันหยุดทำการ (ความผิดปกติของเอกสาร)`;

const InputForm: React.FC<InputFormProps> = ({ onAnalyze, isAnalyzing }) => {
  const [inputData, setInputData] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputData.trim()) {
      onAnalyze(inputData);
    }
  };

  const loadSample = () => {
    setInputData(SAMPLE_DATA);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 md:p-8">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-slate-800 flex items-center gap-2">
          <FileText className="w-5 h-5 text-indigo-600" />
          บันทึกการปฏิบัติงานและหลักฐานประกอบ (Operational Logs & Evidence)
        </h2>
        <p className="text-slate-500 text-sm mt-1">
          ระบุบันทึกการปฏิบัติงาน รายงานสถานะ หรือลำดับเหตุการณ์ เพื่อตรวจสอบความต่อเนื่องและความถูกต้องตามกระบวนการ
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="relative">
          <textarea
            className="w-full h-48 p-4 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none text-slate-700 font-mono text-sm leading-relaxed"
            placeholder="กรุณาระบุข้อมูลหรือวางบันทึกข้อความที่นี่..."
            value={inputData}
            onChange={(e) => setInputData(e.target.value)}
            disabled={isAnalyzing}
          />
          <button
            type="button"
            onClick={loadSample}
            className="absolute top-2 right-2 text-xs bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 px-3 py-1 rounded-full transition-colors flex items-center gap-1 shadow-sm"
            disabled={isAnalyzing}
          >
            <RefreshCw className="w-3 h-3" />
            ตัวอย่างข้อมูล
          </button>
        </div>

        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            disabled={!inputData.trim() || isAnalyzing}
            className={`
              flex items-center gap-2 px-6 py-3 rounded-lg font-medium text-white shadow-lg shadow-indigo-500/30 transition-all
              ${!inputData.trim() || isAnalyzing 
                ? 'bg-slate-400 cursor-not-allowed shadow-none' 
                : 'bg-indigo-600 hover:bg-indigo-700 hover:-translate-y-0.5'
              }
            `}
          >
            {isAnalyzing ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                กำลังประมวลผล...
              </>
            ) : (
              <>
                <ClipboardCheck className="w-5 h-5" />
                เริ่มการตรวจสอบ
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default InputForm;
import React from 'react';
import { AnalysisResult, Metric, Risk } from '../types';
import { 
  AlertCircle, 
  CheckCircle2, 
  TrendingUp, 
  ClipboardList, 
  FileCheck,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from 'recharts';

interface DashboardProps {
  data: AnalysisResult;
  onReset: () => void;
}

const MetricCard: React.FC<{ metric: Metric }> = ({ metric }) => {
  const getColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-emerald-600 bg-emerald-50 border-emerald-100';
      case 'warning': return 'text-amber-600 bg-amber-50 border-amber-100';
      case 'critical': return 'text-rose-600 bg-rose-50 border-rose-100';
      default: return 'text-slate-600 bg-slate-50 border-slate-100';
    }
  };

  return (
    <div className={`p-4 rounded-xl border ${getColor(metric.status)} flex flex-col items-center justify-center text-center transition-all hover:shadow-md`}>
      <span className="text-sm font-medium opacity-80 mb-1">{metric.label}</span>
      <span className="text-3xl font-bold tracking-tight">
        {metric.value}
        <span className="text-lg font-normal ml-1 opacity-70">{metric.unit}</span>
      </span>
    </div>
  );
};

const RiskCard: React.FC<{ risk: Risk }> = ({ risk }) => {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-rose-100 text-rose-700 border-rose-200';
      case 'medium': return 'bg-amber-100 text-amber-700 border-amber-200';
      default: return 'bg-blue-100 text-blue-700 border-blue-200';
    }
  };

  return (
    <div className="border border-slate-100 rounded-lg p-4 bg-slate-50 mb-3 hover:bg-white hover:border-slate-200 hover:shadow-sm transition-all">
      <div className="flex justify-between items-start mb-2">
        <h4 className="font-semibold text-slate-800 text-sm flex-1 mr-2">{risk.issue}</h4>
        <span className={`text-xs px-2 py-0.5 rounded-full font-medium border ${getSeverityColor(risk.severity)} uppercase tracking-wider`}>
          {risk.severity}
        </span>
      </div>
      <p className="text-xs text-slate-500 mb-2">
        <span className="font-medium text-slate-700">ผลกระทบ:</span> {risk.impact}
      </p>
      <div className="text-xs text-emerald-700 bg-emerald-50/50 p-2 rounded border border-emerald-100/50 flex gap-2 items-start">
        <CheckCircle2 className="w-3 h-3 mt-0.5 shrink-0" />
        <span>ข้อเสนอแนะ: {risk.mitigation}</span>
      </div>
    </div>
  );
};

const Dashboard: React.FC<DashboardProps> = ({ data, onReset }) => {
  // Overall score color
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-500';
    if (score >= 50) return 'text-amber-500';
    return 'text-rose-500';
  };

  // Recharts data prep
  const chartData = data.metrics.map(m => ({
    name: m.label,
    value: m.value,
    status: m.status
  }));

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
      
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded font-bold uppercase tracking-wide">รายงานผลการตรวจสอบ (Audit Report)</span>
            <span className="text-slate-400 text-xs">{new Date().toLocaleDateString('th-TH', { year: 'numeric', month: 'long', day: 'numeric'})}</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900">{data.projectTitle}</h1>
        </div>
        <div className="flex items-center gap-4 bg-slate-50 px-4 py-2 rounded-lg border border-slate-100">
          <div className="text-right">
            <div className="text-xs text-slate-500 font-medium uppercase">คะแนนผลการตรวจสอบ</div>
            <div className={`text-2xl font-bold ${getScoreColor(data.overallSentiment)}`}>{data.overallSentiment}/100</div>
          </div>
          <ShieldCheck className={`w-8 h-8 ${getScoreColor(data.overallSentiment)} opacity-80`} />
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {data.metrics.map((metric, idx) => (
          <MetricCard key={idx} metric={metric} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Executive Summary & Highlights */}
        <div className="lg:col-span-2 space-y-6">
          {/* Executive Summary */}
          <section className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-indigo-600" />
              ความเห็นผู้ตรวจสอบ (Audit Opinion)
            </h3>
            <div className="prose prose-slate prose-sm max-w-none text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-lg border border-slate-100">
              {data.executiveSummary}
            </div>
          </section>

          {/* Highlights & Actions Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Highlights */}
            <section className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-full">
              <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-emerald-600" />
                ข้อชมเชย/สิ่งที่ปฏิบัติได้ดี
              </h3>
              <ul className="space-y-3">
                {data.keyHighlights.map((item, idx) => (
                  <li key={idx} className="flex gap-3 text-sm text-slate-600">
                    <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </section>

            {/* Action Items */}
            <section className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-full border-l-4 border-l-indigo-500">
              <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <ChevronRight className="w-5 h-5 text-indigo-600" />
                ข้อเสนอแนะเพื่อการปรับปรุง
              </h3>
              <ul className="space-y-3">
                {data.actionItems.map((item, idx) => (
                  <li key={idx} className="flex gap-3 text-sm font-medium text-slate-700 bg-indigo-50/50 p-2 rounded">
                    <span className="text-indigo-600 font-bold">{idx + 1}.</span>
                    {item}
                  </li>
                ))}
              </ul>
            </section>
          </div>

          {/* Chart Section */}
          <section className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
             <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-slate-600" />
                ตัวชี้วัดสำคัญ (Key Audit Indicators)
              </h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="name" 
                      tick={{fontSize: 12, fill: '#64748b'}} 
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis 
                      tick={{fontSize: 12, fill: '#64748b'}} 
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip 
                      cursor={{fill: '#f1f5f9'}}
                      contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                    />
                    <Bar dataKey="value" radius={[4, 4, 0, 0]} barSize={40}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={
                          entry.status === 'good' ? '#10b981' : 
                          entry.status === 'warning' ? '#f59e0b' : '#f43f5e'
                        } />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
          </section>
        </div>

        {/* Right Column: Risks & Issues */}
        <div className="lg:col-span-1">
          <section className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm sticky top-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-amber-500" />
                ประเด็นข้อตรวจพบ
              </h3>
              <span className="bg-amber-100 text-amber-700 text-xs font-bold px-2 py-1 rounded-full">
                {data.risks.length} รายการ
              </span>
            </div>
            
            <div className="space-y-1">
              {data.risks.map((risk, idx) => (
                <RiskCard key={idx} risk={risk} />
              ))}
              {data.risks.length === 0 && (
                <div className="text-center py-8 text-slate-400 text-sm italic">
                  ไม่พบประเด็นข้อบกพร่องที่มีนัยสำคัญ (No significant findings).
                </div>
              )}
            </div>

            <button 
              onClick={onReset}
              className="w-full mt-6 py-2 px-4 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50 hover:text-slate-800 transition-colors text-sm font-medium"
            >
              เริ่มการตรวจสอบรายการใหม่
            </button>
          </section>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;
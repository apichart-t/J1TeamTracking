
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, TrendAnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    projectTitle: {
      type: Type.STRING,
      description: "A formal title for the internal audit report in Thai.",
    },
    executiveSummary: {
      type: Type.STRING,
      description: "A concise executive summary focusing on process continuity, data integrity, and compliance in Formal Business Thai (ภาษาราชการ).",
    },
    keyHighlights: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Good practices observed or confirmed milestones in Formal Business Thai.",
    },
    risks: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          issue: { type: Type.STRING, description: "The specific discrepancy, gap in continuity, or non-compliance issue found in Formal Business Thai." },
          impact: { type: Type.STRING, description: "The impact on process integrity or reliability in Formal Business Thai." },
          severity: { type: Type.STRING, enum: ["low", "medium", "high"] },
          mitigation: { type: Type.STRING, description: "Professional recommendation to fix the gap or improve the process in Formal Business Thai." },
        },
        required: ["issue", "impact", "severity", "mitigation"],
      },
      description: "List of audit findings, discontinuities, or logical errors.",
    },
    actionItems: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Corrective actions required to rectify findings in Formal Business Thai.",
    },
    metrics: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING, description: "Name of the metric (e.g., Process Completeness, Error Rate) in Thai." },
          value: { type: Type.NUMBER, description: "Numeric value." },
          unit: { type: Type.STRING, description: "Unit (e.g., %, Items, Days)." },
          status: { type: Type.STRING, enum: ["good", "warning", "critical"] },
        },
        required: ["label", "value", "unit", "status"],
      },
      description: "Quantitative metrics extracted or estimated relevant to audit health.",
    },
    overallSentiment: {
      type: Type.NUMBER,
      description: "An Audit Score from 0 (Unreliable/Gaps found) to 100 (Complete/Compliant).",
    },
  },
  required: ["projectTitle", "executiveSummary", "keyHighlights", "risks", "actionItems", "metrics", "overallSentiment"],
};

const trendSchema = {
  type: Type.OBJECT,
  properties: {
    trend: { type: Type.STRING, enum: ["improving", "stable", "deteriorating"], description: "Overall direction of the project status." },
    summary: { type: Type.STRING, description: "Comparison summary in Thai." },
    resolvedIssues: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Issues present in the old log that are resolved in the new log." },
    newRisks: { type: Type.ARRAY, items: { type: Type.STRING }, description: "New risks that appeared in the latest log." },
    progressAssessment: { type: Type.STRING, description: "Assessment of the progress made between the two periods." },
  },
  required: ["trend", "summary", "resolvedIssues", "newRisks", "progressAssessment"]
};

export const analyzeProjectData = async (rawData: string): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `
        Analyze the following raw data/logs.
        Act as a professional **Internal Auditor**.
        Your job is to check for **Continuity of Work**, logical consistency, and completeness.
        
        Raw Data:
        """
        ${rawData}
        """
        
        Output the result in **Formal Business Thai (ภาษาเขียนเชิงธุรกิจ/ภาษาราชการ)**.
        - Use professional terminology (e.g., "พบว่า", "ดำเนินการ", "ข้อบกพร่อง", "ข้อเสนอแนะ").
        - Focus heavily on "Is the work continuous?", "Are there gaps in the timeline?", "Is the evidence sufficient?".
        - "executiveSummary" should be a formal Audit Opinion.
        - "risks" should be "Audit Findings" (ข้อตรวจพบ).
        - "overallSentiment" represents the Audit Score (100 = Fully Compliant/Continuous, 0 = Broken Process/High Risk).
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        systemInstruction: "You are an expert Internal Auditor. You use formal, professional business language (Thai). You are meticulous, detail-oriented, and focused on process continuity, compliance, and evidence validation.",
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as AnalysisResult;
  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};

export const analyzeProgressTrend = async (previousLog: string, currentLog: string): Promise<TrendAnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `
        Compare the following two project logs to determine the trend.
        
        Previous Log (Past):
        """${previousLog}"""
        
        Current Log (Latest):
        """${currentLog}"""
        
        Output in **Thai Language**.
        Determine if the situation is Improving, Stable, or Deteriorating.
        Identify what has been fixed and what new problems have arisen.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: trendSchema,
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as TrendAnalysisResult;
  } catch (error) {
    console.error("Trend Analysis failed:", error);
    throw error;
  }
};
